// Simple alert for demo
document.addEventListener("DOMContentLoaded", () => {
  alert("Welcome to Gayathri Balla's Portfolio!");
});
